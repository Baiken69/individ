package com.example.Dva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DvaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DvaApplication.class, args);
	}

}
